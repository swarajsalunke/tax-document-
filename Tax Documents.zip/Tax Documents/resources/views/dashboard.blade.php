<x-app-layout>
    <x-slot name="header">
        {{ __('Dashboard User') }}
    </x-slot>

    <div class="p-4 bg-white rounded-lg shadow-xs">
        {{ __('You are logged in!') }}
    </div>
</x-app-layout>

